import { Formulario1 } from "./components/Formulario1";



function App() {
  return (
    <div className="App">
      <Formulario1 />
    </div>
  );
}

export default App;
