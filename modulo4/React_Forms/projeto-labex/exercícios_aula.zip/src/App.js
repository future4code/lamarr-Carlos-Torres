import { Formulario1 } from "./components/Formulario1";
import { Formulario2 } from "./components/Formulario2";



function App() {
  return (
    <div className="App">
      {/* <Formulario1 /> */}
      <Formulario2 />
    </div>
  );
}

export default App;
