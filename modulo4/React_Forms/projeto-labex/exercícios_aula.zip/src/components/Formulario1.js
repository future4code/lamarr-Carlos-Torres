import axios from "axios"
import { useState } from "react"



export function Formulario1() {
    const [email, setEmail] = useState("")
    const [senha, setSenha] = useState("")

    const mudaEmail = (event) => {
        setEmail(event.target.value)
    }
    const mudaSenha = (event) => {
        setSenha(event.target.value)
    }

    const body = {
        "email": email,
        "password": senha
    }

    const fazerLogin = () => {
        //axios.post(url, body, headers)
        console.log(body)
    }
   
    return (
        <div>
            <h1> Login - sem tag form</h1>
            <input
                placeholder="E-mail"
                value={email}
                onChange={mudaEmail}
                type="email"
            />
            
            <input 
                placeholder="Senha"
                value={senha}
                onChange={mudaSenha}
                type="password"
            />
            <button onClick={fazerLogin}>Login</button>
        </div>

    )
}